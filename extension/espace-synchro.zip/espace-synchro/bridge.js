// Pont entre la page de l'espace et l'extension (attributs sur <html>, qui résistent au rechargement du contenu de la page).
(function () {
  const H = () => document.documentElement;
  setInterval(() => {
    const h = H(); if (!h) return;
    if (h.getAttribute('data-es-ext') !== '1') h.setAttribute('data-es-ext', '1');
    const c = h.getAttribute('data-es-cmd');
    if (c) { h.removeAttribute('data-es-cmd'); try { const o = JSON.parse(c); chrome.runtime.sendMessage({ type: 'start', key: o.key }); } catch (e) {} }
  }, 400);
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'prog' && H()) H().setAttribute('data-es-prog', JSON.stringify(m.p)); });
})();
