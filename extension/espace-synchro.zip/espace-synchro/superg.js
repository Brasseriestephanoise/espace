/* Espace brasserie – bouton « Synchroniser l'Espace » dans les pages Super G (extension 1.2).
   Un clic, ou l'adresse terminée par #espace-sync, lance la même synchro que le bouton de l'Espace.
   La clé de synchro reste dans l'extension : elle n'apparaît jamais dans cette page ni dans l'adresse.
   État lisible dans l'élément id="espace-sync-status". */
(function () {
  if (window.top !== window || document.getElementById('espace-sync-box')) return;
  let box, btn, st;
  /* #espace-sync noté dès le début du chargement : Super G redirige parfois (ex. / → /dashboard) en perdant la fin de l'adresse. */
  try { if (location.hash === '#espace-sync') sessionStorage.setItem('esp_sync_go', String(Date.now())); } catch (e) {}
  const pad = n => String(n).padStart(2, '0');
  const stamp = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  function ui() {
    if (box) return;
    box = document.createElement('div'); box.id = 'espace-sync-box';
    box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99998;display:flex;flex-direction:column;align-items:flex-end;gap:6px;font:14px/1.35 Arial,sans-serif;max-width:340px';
    st = document.createElement('div'); st.id = 'espace-sync-status'; st.setAttribute('role', 'status'); st.setAttribute('aria-live', 'polite');
    st.style.cssText = 'display:none;background:#1D2420;color:#fff;padding:8px 12px;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.25)';
    btn = document.createElement('button'); btn.id = 'espace-sync-btn'; btn.type = 'button'; btn.textContent = '⟳ Synchroniser l’Espace';
    btn.style.cssText = 'min-height:44px;padding:10px 16px;border:0;border-radius:22px;background:#17936F;color:#fff;font:700 15px Arial,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.25)';
    btn.addEventListener('click', start);
    box.appendChild(st); box.appendChild(btn); (document.body || document.documentElement).appendChild(box);
  }
  function show(txt, kind) {
    ui(); st.textContent = txt; st.style.display = 'block'; st.dataset.state = kind;
    st.style.background = kind === 'ok' ? '#17936F' : kind === 'err' ? '#B42318' : '#1D2420';
    btn.disabled = kind === 'run'; btn.style.opacity = kind === 'run' ? '.6' : '1';
  }
  function start() {
    show('Synchro en cours…', 'run');
    try { chrome.runtime.sendMessage({ type: 'here' }, r => { if (chrome.runtime.lastError) show('Erreur : extension injoignable, rechargez la page (F5).', 'err'); else if (r && !r.ok) show(r.msg, 'err'); }); }
    catch (e) { show('Erreur : extension injoignable, rechargez la page (F5).', 'err'); }
  }
  chrome.runtime.onMessage.addListener(m => {
    if (!m || m.type !== 'prog' || !m.p) return; const p = m.p;
    if (!p.done) { show('Synchro en cours… ' + Math.round(p.pct || 0) + ' % · ' + (p.msg || ''), 'run'); return; }
    if (p.ok) show('Synchro OK – ' + stamp(new Date()) + ' – ' + ((p.log || []).join(', ') || p.msg), 'ok');
    else show(String(p.msg || 'Erreur de synchro').replace(/^❌\s*/, 'Erreur : '), 'err');
  });
  function boot() {
    ui();
    let go = 0; try { go = +sessionStorage.getItem('esp_sync_go') || 0; sessionStorage.removeItem('esp_sync_go'); } catch (e) {}
    if (location.hash === '#espace-sync') { go = go || Date.now(); try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} }
    if (go && Date.now() - go < 60000) start();
  }
  if (document.readyState === 'complete') boot(); else window.addEventListener('load', boot);
})();
