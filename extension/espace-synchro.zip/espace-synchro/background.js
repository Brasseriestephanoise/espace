// Espace brasserie – Synchro Super G (1.2)
// - Bouton « ⟳ Synchroniser l'Espace » dans les pages Super G et adresse …#espace-sync (superg.js) : même synchro, dans l'onglet Super G ouvert.
// - Bouton « Synchroniser Super G » de l'espace : lance la synchro et renvoie l'avancement à la page.
// - Automatique : toutes les heures de 7 h à 21 h et 2 minutes après l'ouverture de Chrome (si l'espace a déjà été synchronisé une fois depuis cet ordinateur).
let busy = false;
const wait = ms => new Promise(r => setTimeout(r, ms));
const send = (tabId, p) => { if (tabId) chrome.tabs.sendMessage(tabId, { type: 'prog', p }).catch(() => {}); };

async function superTab() {
  const found = await chrome.tabs.query({ url: 'https://app.superg.fr/*' });
  if (found.length) return { tab: found[0], created: false };
  const tab = await chrome.tabs.create({ url: 'https://app.superg.fr/orders/list', active: false });
  for (let i = 0; i < 60; i++) { const t = await chrome.tabs.get(tab.id); if (t.status === 'complete') break; await wait(500); }
  return { tab: await chrome.tabs.get(tab.id), created: true };
}

async function runSync(key, back, auto, here) {
  if (busy) { send(back, { pct: 0, done: true, ok: false, msg: 'Une synchro est déjà en cours.' }); return; }
  busy = true;
  try {
    send(back, { pct: 0, msg: 'Ouverture de Super G…' });
    const { tab, created } = here ? { tab: await chrome.tabs.get(here), created: false } : await superTab();
    const [go] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', args: [key],
      func: k => { if (window.__esSync) return false; window.__ESK = k; window.__esProg = { pct: 0, msg: 'Chargement…' }; return true; } });
    // Script de synchro fourni avec l'extension (sync.js, dans ce dossier) : plus rien n'est chargé depuis un site.
    if (go && go.result) await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['sync.js'] });
    // La clé n'est lue qu'au démarrage de sync.js : on l'efface aussitôt de la page.
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => { try { delete window.__ESK; } catch (e) { window.__ESK = ''; } } }).catch(() => {});
    for (let i = 0; i < 900; i++) {
      await wait(1000);
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => window.__esProg || null });
      const p = r && r.result; if (p) send(back, p);
      if (p && p.done) {
        if (p.ok) { await chrome.storage.local.set({ lastOk: Date.now() }); if (created) chrome.tabs.remove(tab.id).catch(() => {}); }
        else if (!auto) chrome.tabs.update(tab.id, { active: true }).catch(() => {});
        else if (created) chrome.tabs.remove(tab.id).catch(() => {});
        await chrome.storage.local.set({ last: { at: Date.now(), ok: p.ok, msg: p.msg } });
        return;
      }
    }
    send(back, { pct: 0, done: true, ok: false, msg: 'La synchro a pris trop de temps : regardez l’onglet Super G.' });
  } catch (e) { send(back, { pct: 0, done: true, ok: false, msg: 'Erreur : ' + (e && e.message || e) }); }
  finally { busy = false; }
}

// Bouton de l'espace : retient l'autorisation pour les synchros automatiques
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.type !== 'start' || !sender.tab) return;
  chrome.storage.local.set({ key: m.key });
  runSync(m.key, sender.tab.id, false);
});

// Bouton « ⟳ Synchroniser l'Espace » (ou #espace-sync) dans une page Super G : clé gardée par l'extension, jamais transmise à la page.
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.type !== 'here' || !sender.tab || !/^https:\/\/app\.superg\.fr\//.test(sender.tab.url || '')) return;
  (async () => {
    const { key, last } = await chrome.storage.local.get(['key', 'last']);
    if (!key) return reply({ ok: false, msg: 'Erreur : cet ordinateur n’a pas encore la clé de synchro. Lancez une fois la synchro depuis l’Espace (Commandes Pro › bouton « Synchroniser Super G »).' });
    if (busy) return reply({ ok: false, msg: 'Erreur : une synchro est déjà en cours.' });
    if (last && Date.now() - last.at < 2 * 60 * 1000) return reply({ ok: false, msg: 'Synchro déjà faite il y a moins de 2 minutes (' + (last.ok ? 'OK' : 'en erreur') + ') : réessayez un peu plus tard.' });
    reply({ ok: true });
    runSync(key, sender.tab.id, false, sender.tab.id);
  })();
  return true;
});

// Synchro automatique
async function autoSync() {
  const h = new Date().getHours(); if (h < 7 || h >= 21) return;
  const { key, lastOk } = await chrome.storage.local.get(['key', 'lastOk']);
  if (!key || (lastOk && Date.now() - lastOk < 50 * 60 * 1000)) return;
  runSync(key, null, true);
}
const plan = () => { chrome.alarms.create('hourly', { periodInMinutes: 60, delayInMinutes: 60 }); chrome.alarms.create('start', { delayInMinutes: 2 }); };
chrome.runtime.onInstalled.addListener(plan);
chrome.runtime.onStartup.addListener(plan);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'hourly' || a.name === 'start') autoSync(); });
