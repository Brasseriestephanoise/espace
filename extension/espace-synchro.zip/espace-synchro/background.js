// Espace brasserie – Synchro Super G
// - Bouton « Synchroniser Super G » de l'espace : lance la synchro et renvoie l'avancement à la page.
// - Automatique : toutes les heures de 7 h à 21 h et 2 minutes après l'ouverture de Chrome (si l'espace a déjà été synchronisé une fois depuis cet ordinateur).
let busy = false;
const wait = ms => new Promise(r => setTimeout(r, ms));
const send = (tabId, p) => { if (tabId) chrome.tabs.sendMessage(tabId, { type: 'prog', p }).catch(() => {}); };

async function superTab() {
  const found = await chrome.tabs.query({ url: 'https://app.superg.fr/*' });
  if (found.length) return { tab: found[0], created: false };
  const tab = await chrome.tabs.create({ url: 'https://app.superg.fr/orders/list', active: false });
  for (let i = 0; i < 60; i++) { const t = await chrome.tabs.get(tab.id); if (t.status === 'complete') break; await wait(500); }
  return { tab: await chrome.tabs.get(tab.id), created: true };
}

async function runSync(key, back, auto) {
  if (busy) { send(back, { pct: 0, msg: 'Une synchro est déjà en cours…' }); return; }
  busy = true;
  try {
    send(back, { pct: 0, msg: 'Ouverture de Super G…' });
    const { tab, created } = await superTab();
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', args: [key],
      func: k => { if (window.__esSync) return; window.__ESK = k; window.__esProg = { pct: 0, msg: 'Chargement…' };
        const s = document.createElement('script'); s.src = 'https://espace.labrasseriestephanoise.com/sync.js?' + Date.now(); document.body.appendChild(s); } });
    for (let i = 0; i < 900; i++) {
      await wait(1000);
      const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => window.__esProg || null });
      const p = r && r.result; if (p) send(back, p);
      if (p && p.done) {
        if (p.ok) { await chrome.storage.local.set({ lastOk: Date.now() }); if (created) chrome.tabs.remove(tab.id).catch(() => {}); }
        else if (!auto) chrome.tabs.update(tab.id, { active: true }).catch(() => {});
        else if (created) chrome.tabs.remove(tab.id).catch(() => {});
        await chrome.storage.local.set({ last: { at: Date.now(), ok: p.ok, msg: p.msg } });
        return;
      }
    }
    send(back, { pct: 0, done: true, ok: false, msg: 'La synchro a pris trop de temps : regardez l’onglet Super G.' });
  } catch (e) { send(back, { pct: 0, done: true, ok: false, msg: 'Erreur : ' + (e && e.message || e) }); }
  finally { busy = false; }
}

// Bouton de l'espace : retient l'autorisation pour les synchros automatiques
chrome.runtime.onMessage.addListener((m, sender) => {
  if (!m || m.type !== 'start' || !sender.tab) return;
  chrome.storage.local.set({ key: m.key });
  runSync(m.key, sender.tab.id, false);
});

// Synchro automatique
async function autoSync() {
  const h = new Date().getHours(); if (h < 7 || h >= 21) return;
  const { key, lastOk } = await chrome.storage.local.get(['key', 'lastOk']);
  if (!key || (lastOk && Date.now() - lastOk < 50 * 60 * 1000)) return;
  runSync(key, null, true);
}
const plan = () => { chrome.alarms.create('hourly', { periodInMinutes: 60, delayInMinutes: 60 }); chrome.alarms.create('start', { delayInMinutes: 2 }); };
chrome.runtime.onInstalled.addListener(plan);
chrome.runtime.onStartup.addListener(plan);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'hourly' || a.name === 'start') autoSync(); });
